import styled from 'styled-components';
const FrontFormTitle = styled.h3 `
  font-weight: normal;
  margin:0;
  font-size: 22px;
  color: #212529;
  margin-top: 90px;
`;
export default FrontFormTitle;
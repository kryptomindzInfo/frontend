import styled from 'styled-components';
const BackBtn = styled.span `
  color: #9ea0a5;
  position: absolute;
  left: 37px;
  padding: 0;
  font-size: 26px;
  font-weight: normal;
`;
export default BackBtn;
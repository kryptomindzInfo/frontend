import styled from 'styled-components';
const InputsWrap = styled.div `
  margin: 43px 0 25px;
`;
export default InputsWrap;
import styled from 'styled-components';

const Logo = styled.h1 `
float:left;
color: white;
font-size: 26px;
font-weight:bold;
margin: 8px 0;
`;
export default Logo;
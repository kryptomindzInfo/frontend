/**
 *
 * Asynchronously loads the component for BankTheme
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

var __wpo = {
  "assets": {
    "main": [
      "/favicon.ico",
      "/runtime.0918c048afad59e1f3d7.js",
      "/"
    ],
    "additional": [
      "/npm.lodash.2523e705dee19b694609.chunk.js",
      "/1.b13452ff04d0b53e3bf8.chunk.js",
      "/npm.intl.5ac934085c33b80d54d5.chunk.js",
      "/3.9fb54123318d0e4abb06.chunk.js",
      "/main.212dcdcd4d7d8044252b.chunk.js",
      "/npm.axios.30ad44325d88e01a0ec7.chunk.js",
      "/npm.babel.4555e4b04dc8aba3e35a.chunk.js",
      "/npm.date-fns.e973c4d9d7afa6ac4cb1.chunk.js",
      "/npm.material-ui.28663c936174ecef6578.chunk.js",
      "/npm.react-app-polyfill.e59782b24f465108c563.chunk.js",
      "/npm.react-color.2975d858cf1d757ec211.chunk.js",
      "/npm.react-grid-system.c349b4ee453aa88488f1.chunk.js",
      "/npm.react-lifecycles-compat.0aeaff3c562d6680843e.chunk.js",
      "/npm.react-modal.4257687c1943c633412e.chunk.js",
      "/npm.react-redux.7a58986db1d077aeeb5d.chunk.js",
      "/npm.react-transition-group.b58ceeaf43ea4cfc8e9b.chunk.js",
      "/npm.reactcss.9cfcf749f36b6436ba19.chunk.js",
      "/npm.warning.8ca94f7a5151009d2fa0.chunk.js",
      "/npm.yup.795836fa03853da17d42.chunk.js",
      "/20.77e555d31be66c64ec2a.chunk.js",
      "/21.c084d4c8b5b0f7145b0b.chunk.js",
      "/22.2d3ded45c56fc4986519.chunk.js",
      "/23.9062dad6d2a13ca898e7.chunk.js",
      "/24.91944ac4b95d9a7a7230.chunk.js",
      "/25.c0be52273d129dfd810e.chunk.js",
      "/26.b55c139463f6c152591c.chunk.js",
      "/27.f95856460ddb3336b997.chunk.js",
      "/28.0f409644c97a55067c5f.chunk.js",
      "/29.8059cdba5acf73fbaafb.chunk.js",
      "/30.59d4fb2af67599f28b2a.chunk.js",
      "/31.0c847e71d1d0c60e1bd4.chunk.js",
      "/32.433ddfcde2491b7e473c.chunk.js",
      "/33.5642240d9fbff2776166.chunk.js",
      "/34.f1278925390d3524d9a5.chunk.js",
      "/35.2105164889a34446042e.chunk.js",
      "/36.1f6193435466b8057b3b.chunk.js",
      "/37.b8049939a674d7d20733.chunk.js",
      "/38.29545efba6529a37a4cc.chunk.js",
      "/39.a16abf7ac4d70db71792.chunk.js",
      "/40.92bf95f0129615bf8c0b.chunk.js",
      "/41.01fce50f8dae3c0f68da.chunk.js",
      "/42.35806c81af5f1facff5e.chunk.js",
      "/43.66bfe8fbf968c2ca8c00.chunk.js",
      "/44.b01533e75310e07a76bb.chunk.js",
      "/45.3e3fc997977d8f197a69.chunk.js",
      "/46.18bbe9db874748ddfca4.chunk.js",
      "/47.5606672e91323cf9ee03.chunk.js",
      "/48.2dbd209f10758be639b0.chunk.js",
      "/49.b088aa26f495b54220da.chunk.js",
      "/50.5477b43a9b0885c9dbef.chunk.js",
      "/51.c8f82b85642491493a7d.chunk.js",
      "/52.111951ef41fd18d2ea2c.chunk.js",
      "/53.ad3220f55047f6b7af48.chunk.js",
      "/54.26d894a664ab0f98ccc7.chunk.js",
      "/55.9070490a577da39fb983.chunk.js",
      "/56.adcb2a87a6060c0f8e19.chunk.js",
      "/57.ff9275a0d2f71336420f.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "8b7a8219abe66af77a91af8e4efa9df38ca0ae33": "/npm.lodash.2523e705dee19b694609.chunk.js",
    "994f907262fe8053971a7ac865d1958ddd1eb2a5": "/1.b13452ff04d0b53e3bf8.chunk.js",
    "7ce1f96cd49345320b0ff91fb3f537d8c43352ec": "/npm.intl.5ac934085c33b80d54d5.chunk.js",
    "2431494be00d12118cbd2fa6fb95f9391245d890": "/3.9fb54123318d0e4abb06.chunk.js",
    "5cb04c2c389fff2e5a155e9c5110314b671742ee": "/main.212dcdcd4d7d8044252b.chunk.js",
    "f60db85c298fbe6927aeb85bbac10cf0ccb2c3f1": "/npm.axios.30ad44325d88e01a0ec7.chunk.js",
    "a4dbe829bf0ba3f39c0bdcd4989bad8dc87da714": "/npm.babel.4555e4b04dc8aba3e35a.chunk.js",
    "ddcab5f52e63a7d0a07278650329758a2a8a49f5": "/npm.date-fns.e973c4d9d7afa6ac4cb1.chunk.js",
    "1f14be23e060e1b89b24172c405655062dae2026": "/npm.material-ui.28663c936174ecef6578.chunk.js",
    "8e4f710cb68832a9bb8c2e24464ea6560e2142b1": "/npm.react-app-polyfill.e59782b24f465108c563.chunk.js",
    "366f8c5a6db14d75382f4668945c3654bbaf668e": "/npm.react-color.2975d858cf1d757ec211.chunk.js",
    "b3b0d9d1a75c6b90f90f65a3210e19fee71d68c8": "/npm.react-grid-system.c349b4ee453aa88488f1.chunk.js",
    "db345c7550370f90a22cd140a6a8d47df0ffc46e": "/npm.react-lifecycles-compat.0aeaff3c562d6680843e.chunk.js",
    "f83a2d36c56bc49398e242353cea48c6bd87ddd2": "/npm.react-modal.4257687c1943c633412e.chunk.js",
    "26a21064469d532b2823edb35de3f8d634c45c77": "/npm.react-redux.7a58986db1d077aeeb5d.chunk.js",
    "a138abd0daa6f546e5c252fd4bb7b305ef716b4b": "/npm.react-transition-group.b58ceeaf43ea4cfc8e9b.chunk.js",
    "f9c4f5dd1feb304d341b4f3d1be36e961b913a63": "/npm.reactcss.9cfcf749f36b6436ba19.chunk.js",
    "d363b298c08cad261dcdbf02b043a20b9983cc11": "/npm.warning.8ca94f7a5151009d2fa0.chunk.js",
    "7a70e84b9c1d6044327824278b9ebb7f3d05a48c": "/npm.yup.795836fa03853da17d42.chunk.js",
    "3b2b25ec443549f3ccc682493f551deb5b027f96": "/runtime.0918c048afad59e1f3d7.js",
    "ce3acfb9efffd976f7a6811527d6021b1f9bf177": "/20.77e555d31be66c64ec2a.chunk.js",
    "f35e571b2bf816e2e747bca1d90ff718856eec79": "/21.c084d4c8b5b0f7145b0b.chunk.js",
    "e1b4e8b14bd7cfc8df737876684f8231d25b0a80": "/22.2d3ded45c56fc4986519.chunk.js",
    "c54b80c7421e18572a9e188591ee330922b61b0d": "/23.9062dad6d2a13ca898e7.chunk.js",
    "12bfc836f2eeb74bb617548bc208c66d39c3dcbe": "/24.91944ac4b95d9a7a7230.chunk.js",
    "2da5ba0196a3eff37c9868ed9ea445e80b73a5fd": "/25.c0be52273d129dfd810e.chunk.js",
    "b4cb6d4525671da037af015fdac699f551f922e6": "/26.b55c139463f6c152591c.chunk.js",
    "b9a26360c38fead0298f9519fb8d85ae9874f936": "/27.f95856460ddb3336b997.chunk.js",
    "730b694c0e479115361644eec621f07cf877ce35": "/28.0f409644c97a55067c5f.chunk.js",
    "2b6ef2eb3c02c2ce664d5e4205965f8b21b9ab95": "/29.8059cdba5acf73fbaafb.chunk.js",
    "dccf94061b6ea5518ad411c7cfcd8a52343f748a": "/30.59d4fb2af67599f28b2a.chunk.js",
    "acd9079f656ca42d9d7593f2b89b2553a1c7f504": "/31.0c847e71d1d0c60e1bd4.chunk.js",
    "2df631a8ac6e62cec613197dd686fe95098fec45": "/32.433ddfcde2491b7e473c.chunk.js",
    "d806542878fa0de0b72b4c2b0946311a88ddd39d": "/33.5642240d9fbff2776166.chunk.js",
    "32d6b6b2d99c2152e8dba88f454369b61c55bfcb": "/34.f1278925390d3524d9a5.chunk.js",
    "0bd776d05af6fbcaa86353f7269718558b02d323": "/35.2105164889a34446042e.chunk.js",
    "3766c40622ddb58a675daacc04344bd3548626fa": "/36.1f6193435466b8057b3b.chunk.js",
    "95754b9b6dbe7415869ebf7eba05d69267efab63": "/37.b8049939a674d7d20733.chunk.js",
    "6c6abe121f6fde18d01ea83c059182fd77cee444": "/38.29545efba6529a37a4cc.chunk.js",
    "f0bfbba14e45642901ebe8fa8f671c174806b0a4": "/39.a16abf7ac4d70db71792.chunk.js",
    "bd0804e2c71173d434f9ff58dc72c991fb5b9228": "/40.92bf95f0129615bf8c0b.chunk.js",
    "e4f0e3755579094d421c95717a0595dbdc4b0627": "/41.01fce50f8dae3c0f68da.chunk.js",
    "1b58a4e3b2e3995e13b455607d438f6fd232e2aa": "/42.35806c81af5f1facff5e.chunk.js",
    "172f6426bdb21bb29c436a2307d149bb5e1ec886": "/43.66bfe8fbf968c2ca8c00.chunk.js",
    "7d74c361a54b60374ea811770133a76aaded885b": "/44.b01533e75310e07a76bb.chunk.js",
    "72777afca0f2e5e377f9432d04a29d03903e5a4c": "/45.3e3fc997977d8f197a69.chunk.js",
    "d570e6b7c7daaf74c0045ff2511f13f81ebecf7b": "/46.18bbe9db874748ddfca4.chunk.js",
    "0233ce476593ac3bb665678d09b144543098e395": "/47.5606672e91323cf9ee03.chunk.js",
    "a68cc430bff05995748417114d11ab7796433a0a": "/48.2dbd209f10758be639b0.chunk.js",
    "1441206c6e5866855e068c8ed6fccbf66f10ca5a": "/49.b088aa26f495b54220da.chunk.js",
    "e0d4960c9673d68d1a27f5bc78dc6edb06249222": "/50.5477b43a9b0885c9dbef.chunk.js",
    "37787bd1185ef30fe5ae66916952a831a9e466b8": "/51.c8f82b85642491493a7d.chunk.js",
    "9590acae956c35ac6f82ff7350e19f1cf961ad44": "/52.111951ef41fd18d2ea2c.chunk.js",
    "90fdda6b0e90c46177722fb71f8b375f74f17f05": "/53.ad3220f55047f6b7af48.chunk.js",
    "e331a26a97734d33383daf808059f946e47754f0": "/54.26d894a664ab0f98ccc7.chunk.js",
    "7d2bd4a6fe12bcd86b473dea9f00399474d3170d": "/55.9070490a577da39fb983.chunk.js",
    "c21fc6a2786d60edaa4db72699537edc71fa5c7c": "/56.adcb2a87a6060c0f8e19.chunk.js",
    "4064f6952f17b8e441dfd53106305a8b05cfd117": "/57.ff9275a0d2f71336420f.chunk.js",
    "0382d5ef609a72b9af44765de5497b4e357c7ac8": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "9/12/2020, 5:22:05 pm",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });
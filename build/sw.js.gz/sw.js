var __wpo = {
  "assets": {
    "main": [
      "/favicon.ico",
      "/runtime.34392c5fedf7b6c9c1e8.js",
      "/"
    ],
    "additional": [
      "/npm.lodash.2523e705dee19b694609.chunk.js",
      "/1.b13452ff04d0b53e3bf8.chunk.js",
      "/npm.intl.5ac934085c33b80d54d5.chunk.js",
      "/3.9fb54123318d0e4abb06.chunk.js",
      "/4.3a68c09f65d24cfab32c.chunk.js",
      "/main.ec2972e5ed669cdc91da.chunk.js",
      "/npm.axios.897982724b5cd7da00a6.chunk.js",
      "/npm.babel.26972ab2b6986b8fdb4e.chunk.js",
      "/npm.date-fns.1e661f798df0cd7c27fa.chunk.js",
      "/npm.material-ui.538c83dec5111ee50f28.chunk.js",
      "/npm.react-app-polyfill.1c85ea4a4c368d6cb69a.chunk.js",
      "/npm.react-color.d3aebb04e4a4bf365f5c.chunk.js",
      "/npm.react-grid-system.ea47f69990ec7e2868b1.chunk.js",
      "/npm.react-lifecycles-compat.e4f1c74017e37729a7e9.chunk.js",
      "/npm.react-modal.5bb02a9950ef621a4af9.chunk.js",
      "/npm.react-redux.0df249fe461b65ec3bd3.chunk.js",
      "/npm.react-transition-group.236d095b4daaee46de05.chunk.js",
      "/npm.reactcss.179515f81fb100cd5bc1.chunk.js",
      "/npm.warning.b1c636eadc4943591be1.chunk.js",
      "/npm.yup.f99790571841b4ea1138.chunk.js",
      "/21.4f9c6c605086cdeb8a1c.chunk.js",
      "/22.ea26355342392146b700.chunk.js",
      "/23.59a0b75ca6729899739d.chunk.js",
      "/24.619bd800096284ac9347.chunk.js",
      "/25.22b20adffddc47b9be7a.chunk.js",
      "/26.4c7b3be5c8460a619e7c.chunk.js",
      "/27.e12b466fe8d93daf642e.chunk.js",
      "/28.a2595b209fa0e06b51f0.chunk.js",
      "/29.ddc8ce19cbfcfa70b5a1.chunk.js",
      "/30.1510b33cf3f11e89da8e.chunk.js",
      "/31.07e34edf04b5c5b85eb5.chunk.js",
      "/32.0010edf3fe97880a5be3.chunk.js",
      "/33.2517200e3bc1b50b0654.chunk.js",
      "/34.c40a46fe37de2a157edf.chunk.js",
      "/35.b04f3603cb092383e329.chunk.js",
      "/36.626175da61b5ef1459b9.chunk.js",
      "/37.188aedb38643b99b8aa4.chunk.js",
      "/38.54c70178aa28b6eef4d9.chunk.js",
      "/39.d1bedc07f4b721fb046a.chunk.js",
      "/40.6d90569a4db7fbc7232b.chunk.js",
      "/41.50ed11557506aec6fb82.chunk.js",
      "/42.c87dfa4532db89a6400c.chunk.js",
      "/43.c4cd29c02b91d262c504.chunk.js",
      "/44.9cd345a962ab9019ed8f.chunk.js",
      "/45.7ba8a8a219fd68d0d71a.chunk.js",
      "/46.34d979ee68fd534c3f4c.chunk.js",
      "/47.3e436dbe467fa61165ed.chunk.js",
      "/48.c37009e66a1344772894.chunk.js",
      "/49.ee59808a06b8a8c24750.chunk.js",
      "/50.acabb7199af47cb0a485.chunk.js",
      "/51.50a885b11bfecc3cfa49.chunk.js",
      "/52.c19ef10185d0bb83a77e.chunk.js",
      "/53.94d32d1060c446dd6662.chunk.js",
      "/54.2f2b5f756b9e01ae5571.chunk.js",
      "/55.a011d888d5552837d54b.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "8b7a8219abe66af77a91af8e4efa9df38ca0ae33": "/npm.lodash.2523e705dee19b694609.chunk.js",
    "994f907262fe8053971a7ac865d1958ddd1eb2a5": "/1.b13452ff04d0b53e3bf8.chunk.js",
    "7ce1f96cd49345320b0ff91fb3f537d8c43352ec": "/npm.intl.5ac934085c33b80d54d5.chunk.js",
    "2431494be00d12118cbd2fa6fb95f9391245d890": "/3.9fb54123318d0e4abb06.chunk.js",
    "93531df630977f52a7c5490b990ee6fb0c38660f": "/4.3a68c09f65d24cfab32c.chunk.js",
    "ef494cb111d19ff5b83ba6e897045bd03892577c": "/main.ec2972e5ed669cdc91da.chunk.js",
    "05c66cf6003afe978789eadf66bc125b583eee55": "/npm.axios.897982724b5cd7da00a6.chunk.js",
    "c778f65d54d8c72774b17cb126a3714a93c9005f": "/npm.babel.26972ab2b6986b8fdb4e.chunk.js",
    "48659da85a9d9929da64fd05c57eef8e780aaf98": "/npm.date-fns.1e661f798df0cd7c27fa.chunk.js",
    "6769722b45cc563acc72d4ad5909b3e7436ec29a": "/npm.material-ui.538c83dec5111ee50f28.chunk.js",
    "1628afd7e3d188634c4aa0b2d27ea5e7f59a08fd": "/npm.react-app-polyfill.1c85ea4a4c368d6cb69a.chunk.js",
    "55f850c5a2817585fa5667e2febc09885ef781b4": "/npm.react-color.d3aebb04e4a4bf365f5c.chunk.js",
    "30ee015d160e57dcab1e172bff423f4e2181a827": "/npm.react-grid-system.ea47f69990ec7e2868b1.chunk.js",
    "d56487336dfbe864b324d83d54ae91918938a86f": "/npm.react-lifecycles-compat.e4f1c74017e37729a7e9.chunk.js",
    "b806219583170742ae333561ae5781168f9d38ca": "/npm.react-modal.5bb02a9950ef621a4af9.chunk.js",
    "445d70005889e41281edc26c2c3fd303f1bd40e1": "/npm.react-redux.0df249fe461b65ec3bd3.chunk.js",
    "e212f2ec59bf54aeae4b16ca8c022499b4615215": "/npm.react-transition-group.236d095b4daaee46de05.chunk.js",
    "e1601bf4f10538ca41b7a9173c627e2b9180db69": "/npm.reactcss.179515f81fb100cd5bc1.chunk.js",
    "82f2847cab08b82ad31a5ed5336c53d0570fcc1a": "/npm.warning.b1c636eadc4943591be1.chunk.js",
    "aedca10a5e64551a70b8c52a6afe1ce3f118de25": "/npm.yup.f99790571841b4ea1138.chunk.js",
    "39526c16ac675bbe20d58b12dff8a99799b0e991": "/runtime.34392c5fedf7b6c9c1e8.js",
    "b5c46e491653568e2582b90dc5e1aeac60a596cc": "/21.4f9c6c605086cdeb8a1c.chunk.js",
    "70ce99e999be09131e32e05744fb30f08ff16d14": "/22.ea26355342392146b700.chunk.js",
    "80df2a752bba70f06fb25cf0dc152db36efd8ad3": "/23.59a0b75ca6729899739d.chunk.js",
    "eeea24f41b25e4c1491f813f5c6e044b4012da90": "/24.619bd800096284ac9347.chunk.js",
    "0ae42b6245defe51784213fe76d4ed08cbcbaab6": "/25.22b20adffddc47b9be7a.chunk.js",
    "cbc0c43db9d781ad888f7679b4d9b7a498a1da4e": "/26.4c7b3be5c8460a619e7c.chunk.js",
    "7010d6a980d73787f3b959f232d4b7dca1f24524": "/27.e12b466fe8d93daf642e.chunk.js",
    "dd059843fc67d08c47fb73efd21ff68aaa7a61c2": "/28.a2595b209fa0e06b51f0.chunk.js",
    "0ce12036310488f3a079654c8e6a0a7659ca7a57": "/29.ddc8ce19cbfcfa70b5a1.chunk.js",
    "b2e01cbfef9adc708f4b78795900f73b9e609d89": "/30.1510b33cf3f11e89da8e.chunk.js",
    "acd9079f656ca42d9d7593f2b89b2553a1c7f504": "/31.07e34edf04b5c5b85eb5.chunk.js",
    "a32872609159d0dabbb521d30a666640c3a386c8": "/32.0010edf3fe97880a5be3.chunk.js",
    "4cf882523c8e83891363d2a301914aedc70e79b5": "/33.2517200e3bc1b50b0654.chunk.js",
    "43e1c94fdea29fd51c541e031449d4e60cbfa96c": "/34.c40a46fe37de2a157edf.chunk.js",
    "3f77bd39f6a3268e185ba3dcdab0314e5ebfe4bf": "/35.b04f3603cb092383e329.chunk.js",
    "2a5bffcdacf91759ec711944f5ae775ad298c8f3": "/36.626175da61b5ef1459b9.chunk.js",
    "cc9cfa2e7f7c7e7b62c5dfb7966ac802167dc428": "/37.188aedb38643b99b8aa4.chunk.js",
    "a65ba93b39efb799683c98e1de686d44c345a428": "/38.54c70178aa28b6eef4d9.chunk.js",
    "06fd77df768179a19ccc9bc2a3bfdb119d323780": "/39.d1bedc07f4b721fb046a.chunk.js",
    "bc8e11187e3bbaf408f0110c7b69b73f6fe8e81e": "/40.6d90569a4db7fbc7232b.chunk.js",
    "29ba04f05bb66c18eced4bc945b13d192ff8a390": "/41.50ed11557506aec6fb82.chunk.js",
    "b8f742aaca780d48510b26307a8064ac68faeb63": "/42.c87dfa4532db89a6400c.chunk.js",
    "8965dde9b192e1aa0efe483f4242652489afc918": "/43.c4cd29c02b91d262c504.chunk.js",
    "a30ae672063c1ffb4a61718363a89110e072e678": "/44.9cd345a962ab9019ed8f.chunk.js",
    "f8f06b7bcd1380720cdb1c5d30425e0701d329f4": "/45.7ba8a8a219fd68d0d71a.chunk.js",
    "66b1dbb832905bba77ffacdb315096b7346d3d17": "/46.34d979ee68fd534c3f4c.chunk.js",
    "943be46bdddf14b8946db6dea00d36aba8d92589": "/47.3e436dbe467fa61165ed.chunk.js",
    "1e7327454016c7cf465d0a3114d2db74103011f2": "/48.c37009e66a1344772894.chunk.js",
    "90bfc768c8d65c4c1d5ec42882f0fe3d4594aa0d": "/49.ee59808a06b8a8c24750.chunk.js",
    "3f2e87a437f29d2cfd3487612d714d68063b88fc": "/50.acabb7199af47cb0a485.chunk.js",
    "e2fd8e87a3aba72984573690e45776ce03e6fc41": "/51.50a885b11bfecc3cfa49.chunk.js",
    "eff7d7eb376ca18d29d533bdcc1c9db92d1c2bb9": "/52.c19ef10185d0bb83a77e.chunk.js",
    "ef3d14fbb3e3ae0a02b7917a33bdf63b460fad89": "/53.94d32d1060c446dd6662.chunk.js",
    "909f20063176323aa581a8f2a6111478e00f2f80": "/54.2f2b5f756b9e01ae5571.chunk.js",
    "2c46b5c6dbe08b22ddc485cda6f21b6adffb276d": "/55.a011d888d5552837d54b.chunk.js",
    "a3896dd580163d250fb6f78c60a97b927c450d69": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "8/4/2020, 10:50:09 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });